chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(e=>console.error("Failed to set side panel behavior:",e));
